<?php

$conn = mysqli_connect("localhost","root","","homeservice")
or die("cannot connected");
?>
