<?php

    $servername = "localhost";
    $username = "root";
    $password = "";

    // Create connection
    $conn = new mysqli($servername, $username, "");
    // Check connection
    if ($conn==false) {
        die("Connection failed: " . $conn->connect_error);
    }
    $db = mysqli_select_db($conn, "homeservice");
    					if(isset($_POST['Submit'])){

            $org_name = $_POST['org_name'];
              
              $start_location = $_POST['start_location'];

              $fare= $_POST['fare'];
              $car_type= $_POST['car_type'];
              
               $rent_preference = $_POST['rent_preference'];
			   

               $rent_type = $_POST['rent_type'];
              
              
              
                 }
     $r1 = "INSERT INTO car_rent(org_name,start_location,fare,car_type,rent_preference,rent_type) VALUES('$org_name',
                 '$start_location','$fare','$car_type','$rent_preference','$rent_type')";
              if ($conn->query($r1) === TRUE) {
                echo "Succesfully done";
                  } else {
                  echo " Error:";
                   }
                        
    ?>
              